package geekbrains.lessonNumber1;

public class Main {

    public static void main(String[] args) {
        float e;
        int a, b, c, d;
        a = 3; b = 5; c = 8; d = 2;
        e = calcExpression(a, b, c, d);
        System.out.println(a + " * (" + b + " + " + c  + "/" + d + ") = " + e);

        a = 8; b = 5;
        System.out.println(a + "+" + b + " в диапазоне 10..20? " + isInRange(a, b));
        a = 10; b = 11;
        System.out.println(a + "+" + b + " в диапазоне 10..20? " + isInRange(a, b));

        isPositive(0);
        isPositive(-9);
        isPositive(4);

        helloName("Иммануил");
        helloName("Кант");

        int Y = 1980;
        System.out.println(Y + " високосный? " + isLeapYear(Y));
        Y = 1985;
        System.out.println(Y + " високосный? " + isLeapYear(Y));
        Y = 1800;
        System.out.println(Y + " високосный? " + isLeapYear(Y));
        Y = 1600;
        System.out.println(Y + " високосный? " + isLeapYear(Y));
    }

    public static float calcExpression(int a, int b, int c, int d) {
        return a * (b + (float) c / d);
    }

    public static boolean isInRange(int a, int b) {
        return (a + b > 9) & (a + b < 21);
    }

    public static void isPositive(int x) {
        boolean pos = x > -1;
        if (pos == true) {
            System.out.println(x + " положительное.");
        } else {
            System.out.println(x + " отрицательное.");
        }
    }

    public static void helloName(String name) {
        System.out.println("Привет, " + name + "!");
    }

    public static boolean isLeapYear(int Year) {
        return (Year % 4 == 0) & ((Year % 100 != 0) | (Year % 400 == 0));
    }
}